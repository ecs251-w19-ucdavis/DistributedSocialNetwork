Fabricator(:global_mute_word) do
  phrase     "MyString"
  created_at "2019-03-10 03:24:20"
end
