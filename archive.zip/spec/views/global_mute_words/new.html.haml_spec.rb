require 'rails_helper'

RSpec.describe "global_mute_words/new.html.haml", type: :view do
  pending "add some examples to (or delete) #{__FILE__}"
end
